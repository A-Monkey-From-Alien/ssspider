# -*- coding: UTF-8 -*-
from persistence.base import Base


class Mongo(Base):
    def __init__(self):
        pass

    def list(self):
        pass

    def get(self):
        pass

    def update(self):
        pass

    def delete(self):
        pass

    def add(self):
        pass

    def handler(self):
        pass
