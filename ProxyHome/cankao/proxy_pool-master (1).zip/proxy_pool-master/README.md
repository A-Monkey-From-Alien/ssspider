## IP 代理池项目

## 依赖

scrapy/mongodb/bs4/pymongo

## 使用

1. git clone git@github.com:lujqme/proxy_pool.git
2. cd proxy_pool
3. python start.py


## 贡献代码

1. fork && git clone git@github.com:username/proxy_pool.git
2. cd proxy_pool
3. scrapy genspider name domain
4. coding
5. git commit -m "your commit"
6. git push -u origin master
7. pull request